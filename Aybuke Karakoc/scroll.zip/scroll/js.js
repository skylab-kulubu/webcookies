
  const boxes = document.querySelectorAll(".box");
  
  function onVisibilityChange(entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("animate");
        observer.unobserve(entry.target);
      }
    });
  }
  
  const observer = new IntersectionObserver(onVisibilityChange);
  
  boxes.forEach(box => {
    observer.observe(box);
  });
